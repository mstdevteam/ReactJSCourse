
import './MyForm.css'


export default function Modal({ isVisible, errMessage = "" }) {

  if (isVisible) {
    return (
      <div id='modal' className='flex' >
        <div id='modal-content' className='flex'>
          <h3 style={{ color: errMessage ? 'red' : "green" }}>{errMessage != null ? errMessage : "The form has been submitted Successfully"}</h3>
        </div>
      </div>
    )
  }

}

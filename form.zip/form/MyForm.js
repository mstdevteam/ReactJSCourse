import React, { useState } from 'react'
import './MyForm.css'
import Modal from './Modal';

export default function MyForm() {

     const [errMessage , setErrMessage] = useState(null)
    const [showModal , setShowModal] = useState(false)
    const [student, setStudent] = useState({
        name: "",
        email: "",
        phoneNumber: "",
        gender: ""
    })

    const [devices, setDevices] = useState([
        {name : "mac"},
        {name : "iphone"}
    ])

    const btnIsDisabled = student.name === "" || student.email === "" || student.phoneNumber === ""

    function handleFormSubmit(e) {
        e.preventDefault();
        setErrMessage(null)
        if(!student.email.includes('@')){
            setErrMessage("Email format is incorrect...")
        }else if(student.phoneNumber.length !== 10 || !student.phoneNumber.startsWith("05")){
            setErrMessage("Phone number format is incorrect...")
        }
        setShowModal(true)

    }

    function handleDivClick () {
        if(showModal){
        setShowModal(false)
        }

    }
    return (
        <div className='form-container'  onClick={handleDivClick}>
            <form className="my-form">
                <h2 className="form-title">Student Registration</h2>

                <div className="form-group">
                    <label>Name :</label>
                    <input
                        type="text"
                        value={student.name}
                        onChange={(e) => setStudent({ ...student, name: e.target.value })}
                        className="form-input"
                    />
                </div>

                <div className="form-group">
                    <label>Email :</label>
                    <input
                        type="email"
                        value={student.email}
                        onChange={(e) => setStudent({ ...student, email: e.target.value })}
                        className="form-input"
                    />
                </div>

                <div className="form-group">
                    <label>Phone Number :</label>
                    <input
                        type="number"
                        value={student.phoneNumber}
                        onChange={(e) => setStudent({ ...student, phoneNumber: e.target.value })}
                        className="form-input"
                    />
                </div>

                <hr className="divider" />

                <div className="form-group checkbox-group">
                    <label>
                        <input
                            type="checkbox"
                            checked={student.isMember}
                            onChange={() =>
                                setStudent({ ...student, isMember: !student.isMember })
                            }
                        />
                        Are you member?
                    </label>
                </div>

                <div className="form-group radio-group">
                    <label>
                        <input
                            type="radio"
                            value="Male"
                            checked={student.gender === "Male"}
                            onChange={(e) =>
                                setStudent({ ...student, gender: e.target.value })
                            }
                        />
                        Male
                    </label>

                    <label>
                        <input
                            type="radio"
                            value="Female"
                            checked={student.gender === "Female"}
                            onChange={(e) =>
                                setStudent({ ...student, gender: e.target.value })
                            }
                        />
                        Female
                    </label>
                </div>

                <div className="form-group">
                    <label>Year of Study:</label>
                    <select
                        value={student.yearOfStudy}
                        onChange={(e) =>
                            setStudent({ ...student, yearOfStudy: e.target.value })
                        }
                        className="form-select"
                    >
                        <option value="">Select year</option>
                        <option value="a">a</option>
                        <option value="b">b</option>
                        <option value="c">c</option>
                        <option value="d">d</option>
                    </select>
                </div>

                <div className="btn-group">
                    <button
                        type='button'
                        onClick={() => setStudent({
                            name: "",
                            email: "",
                            isMember: false,
                            gender: "",
                            yearOfStudy: "",
                        })}
                        className="btn reset-btn"
                    >
                        Reset
                    </button>

                    <button
                        type='submit'
                        disabled={btnIsDisabled}
                        className={`btn submit-btn ${btnIsDisabled ? "disableBtn" : ""}`}
                        onClick={handleFormSubmit}
                    >
                        Submit
                    </button>
                </div>
            </form>
            <Modal isVisible={showModal} errMessage={errMessage} />
        </div>
    );
}
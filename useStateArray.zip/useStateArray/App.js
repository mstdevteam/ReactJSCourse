import { useState } from "react"


let nextId = 5;

export default function App() {

    const [newDevice, setNewDevice] = useState("")
    const [devices, setDevices] = useState([
        { uniqueId: 1, type: "mac" },
        { uniqueId: 2, type: "iphone" },
        { uniqueId: 3, type: "iPad" },
        { uniqueId: 4, type: "windows" },
    ])

    const devicesList = devices.map((d) =>
        <li key={d.uniqueId}>{d.type}{" "}
            <button onClick={() =>{
                handleDeleteDevice(d.uniqueId)
            }}>Delete</button>
            <button
            onClick={() =>{
                handleUpdateDevice(d.uniqueId)
            }} 
            >Update</button>
        </li>

    )

    function handleAddDevice(e) {
         setDevices([...devices, {uniqueId : nextId, type : e.target.value}])
         nextId = nextId + 1;
    }

    function handleDeleteDevice(id){
     const newDevices = devices.filter( (d) => {
        return d.uniqueId !== id
     })
        setDevices(newDevices)
    }

    function handleUpdateDevice(id){
        
        const newDevices = devices.map( (d) => {
            if(d.uniqueId === id){
                let newDevice = {...d , type : d.type + " 🤩 "};
                return newDevice;
            }else{
                return d
            }
        })
        setDevices(newDevices)
    }

    return (
        <div>
            <ol>
                {devicesList}
            </ol>
            <label>Add device:</label>
            <input
                value={newDevice}
                onChange={(e) => {
                    setNewDevice(e.target.value)
                }} />
            <button value={newDevice} onClick={(e) => { handleAddDevice(e) }}>Add</button>
        </div>
    )
}

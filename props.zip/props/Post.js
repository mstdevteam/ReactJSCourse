
export default function Post({ name, email = "no email",lastName}) {

    return (
        <div>
            {name ? (<div style={{ padding: "10px", margin: "25px", borderRadius: "10px", border: "solid teal 2px" }}>
                <h2> <span style={{ color: "red", fontSize: "20px" }}>Name : </span>{name}</h2>
                <hr />
                <p> <span style={{ color: "blue", fontSize: "20px" }}>Last name : </span> {lastName}</p>
                <p> <span style={{ color: "green", fontSize: "20px" }}>Email : </span> {email}</p>
            </div>) : <div></div>}
        </div>

    )
}

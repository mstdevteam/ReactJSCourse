
import './Button.css'

export default function Button({ title, children }) {
  return (
    <button className="TagButton">
      {title}
      {children}
    </button>
  )

}

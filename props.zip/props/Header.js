
export default function Header() {
    return (
        <div style={{
            position: "relative",
            height: "250px",
            overflow: "hidden",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            color: "white",
            fontSize: "40px",
            fontWeight: "bold",
            boxShadow: "0px 5px 13px rgba(0,0,0,0.4)"
        }}>
            
            <video
                autoPlay
                loop
                muted
                playsInline
                style={{
                    position: "absolute",
                    top: 0,
                    left: 0,
                    width: "100%",
                    height: "100%",
                    objectFit: "cover",
                    zIndex: -1
                }}
            >
                <source src="/videos/header.mp4" type="video/mp4" />
                no video
            </video>

            <div style={{
                position: "absolute",
                top: 0,
                left: 0,
                width: "100%",
                height: "100%",
                background: "rgba(0,0,0,0.4)",
                zIndex: 0
            }}></div>

            <div style={{ zIndex: -1 }}>
                Welcome to website
            </div>
        </div>
    )
}





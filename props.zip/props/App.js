import Header from "./Header";
import '../App.css'
import Post from "./Post";
import SideMenu from "./SideMenu";

export default function App() {

    const posts = [
        {id : 1, name : "Yones" , lastName : "D"},
        {id : 2, name : "ahmad", lastName : "T"},
        {id : 3, name : "noor" ,lastName : "k"},
    ]

    const postsList = posts.map((post) => <Post key={post.id} name={post.name}  lastName={post.lastName}/> ) 
    
    return (
        <div className='App'>
            <Header >
            </Header>
            <div style={{ display: "flex", justifyContent: "center" }}>
                <div style={{ display: "flex", width: "60%" }}>
                    <div style={{ width: "70%" }}>
                       {postsList}
                    </div>
                    <div>
                        <SideMenu />
                    </div>
                </div>
            </div>

        </div>
    )
}

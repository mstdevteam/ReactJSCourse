import Button from "./Button";

export default function SideMenu() {

    const tagButtons = [
        {
            id: 1,
            title: "hi"
        },
        {
            id: 2,
            title: "hello"
        },
        {
            id: 3,
            title: "hello",
            c: (
                <div style={{ position: "relative" }}>
                    <span>📩 Inbox</span>
                    <span style={
                        {
                            backgroundColor: "red",
                            color: "white",
                            borderRadius: "50%",
                            padding: "2px 6px",
                            fontSize: "12px",
                            position: "absolute",
                            top: "-15px",
                            right: "-15px"
                        }
                    }
                    >4</span>
                </div>
            )
        },
        {
            id: 4,
            title: "bye",
            c: (<h3>koko</h3>)
        }
    ]

    const tagButtonsList = tagButtons.map((tagButton) => <Button key={tagButton.id} title={tagButton.title}  children={tagButton.c}/>)

    return (
        <div style={{ margin: "25px", border: "5px solid teal" }}>
            {tagButtonsList}
        </div>
    )
}

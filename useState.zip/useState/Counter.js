import { useState } from 'react';
import './Counter.css'

export default function Counter() {

    const [counter, setCounter] = useState(0)


    function handleClick1() {
        setCounter(counter - 1)
    }

    function handleClick2() {
        setCounter(counter + 1)
    }
    return (
        <div style={{ display: "flex", justifyContent: "center", alignItems: "center" }}>
            <button onClick={handleClick1}> - </button>
            <h2 className={counter >= 0 ? "counterBlue" : "counterRed"} >{counter}</h2>
            <button onClick={handleClick2}> + </button>

        </div>
    )
}

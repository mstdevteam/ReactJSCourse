import Counter from './Counter'

export default function App() {
  return (
    <div>
    <Counter />
    </div>
  )
}

import { useContext } from "react"
import { FormInputsContext } from "./context/FormInputsContext"



export default function GenericInputDrilling() {
    const inputs =  useContext(FormInputsContext)
    return (
        <>
            <label>{inputs.inputTitle}</label>
            <input
                type={inputs.inputType}
                value={inputs.currentValue}
                onChange={(e) => inputs.handleInputValue(e.target.value)}
                className={inputs.stylee}
            />
        </>
    )
}

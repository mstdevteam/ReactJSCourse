import { createContext } from "react";


export let FormInputsContext = createContext(
    {
        inputTitle : "",
        currentValue :null,
        inputType : "",
        handleInputValue :null,
        stylee : ""

    }
)
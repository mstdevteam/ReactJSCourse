import React, { useState } from 'react'
import './MyForm.css'
import Modal from './Modal';
import GenericInput from './GenericInput';
import { FormInputsContext } from './context/FormInputsContext';

export default function MyForm() {

    const [errMessage, setErrMessage] = useState(null)
    const [showModal, setShowModal] = useState(false)
    const [student, setStudent] = useState({
        name: "",
        email: "",
        phoneNumber: "",
        gender: ""
    })


    const btnIsDisabled = student.name === "" || student.email === "" || student.phoneNumber === ""

    function handleFormSubmit(e) {
        e.preventDefault();
        setErrMessage(null)
        if (!student.email.includes('@')) {
            setErrMessage("Email format is incorrect...")
        } else if (student.phoneNumber.length !== 10 || !student.phoneNumber.startsWith("05")) {
            setErrMessage("Phone number format is incorrect...")
        }
        setShowModal(true)

    }

    function handleDivClick() {
        if (showModal) {
            setShowModal(false)
        }

    }


    function handleChangeName(value) {
        setStudent({ ...student, name: value })
    }

    function handleChangeEmail(value) {
        setStudent({ ...student, email: value })
    }

    function handleChangePhoneNumber(value) {
        setStudent({ ...student, phoneNumber: value })
    }


    return (
        <div className='form-container' onClick={handleDivClick}>
            <form className="my-form">
                <h2 className="form-title">Student Registration</h2>

                <div className="form-group">

                    <FormInputsContext.Provider value={
                        {
                            inputTitle: "Name :",
                            currentValue: student.name,
                            inputType: "text",
                            handleInputValue: handleChangeName,
                            stylee: "form-input",
                        }
                    }>
                        <GenericInput />
                    </FormInputsContext.Provider>

                </div>
                <div className="form-group">

                    <FormInputsContext.Provider value={
                        {
                            inputTitle: "Email :",
                            currentValue: student.email,
                            inputType: "email",
                            handleInputValue: handleChangeEmail,
                            stylee: "form-input",
                        }
                    }>
                        <GenericInput />
                    </FormInputsContext.Provider>
                </div>
                <div className="form-group">
                    <FormInputsContext.Provider value={{
                          inputTitle: "Phone Number :",
                            currentValue: student.phoneNumber,
                            inputType: "number",
                            handleInputValue: handleChangePhoneNumber,
                            stylee: "form-input",
                    }}>
                        <GenericInput />
                    </FormInputsContext.Provider>

                </div>
                <hr className="divider" />

                <div className="form-group checkbox-group">
                    <label>
                        <input
                            type="checkbox"
                            checked={student.isMember}
                            onChange={() =>
                                setStudent({ ...student, isMember: !student.isMember })
                            }
                        />
                        Are you member?
                    </label>
                </div>

                <div className="form-group radio-group">
                    <label>
                        <input
                            type="radio"
                            value="Male"
                            checked={student.gender === "Male"}
                            onChange={(e) =>
                                setStudent({ ...student, gender: e.target.value })
                            }
                        />
                        Male
                    </label>

                    <label>
                        <input
                            type="radio"
                            value="Female"
                            checked={student.gender === "Female"}
                            onChange={(e) =>
                                setStudent({ ...student, gender: e.target.value })
                            }
                        />
                        Female
                    </label>
                </div>

                <div className="form-group">
                    <label>Year of Study:</label>
                    <select
                        value={student.yearOfStudy}
                        onChange={(e) =>
                            setStudent({ ...student, yearOfStudy: e.target.value })
                        }
                        className="form-select"
                    >
                        <option value="">Select year</option>
                        <option value="a">a</option>
                        <option value="b">b</option>
                        <option value="c">c</option>
                        <option value="d">d</option>
                    </select>
                </div>

                <div className="btn-group">
                    <button
                        type='button'
                        onClick={() => setStudent({
                            name: "",
                            email: "",
                            isMember: false,
                            gender: "",
                            yearOfStudy: "",
                        })}
                        className="btn reset-btn"
                    >
                        Reset
                    </button>

                    <button
                        type='submit'
                        disabled={btnIsDisabled}
                        className={`btn submit-btn ${btnIsDisabled ? "disableBtn" : ""}`}
                        onClick={handleFormSubmit}
                    >
                        Submit
                    </button>
                </div>
            </form>
            <Modal isVisible={showModal} errMessage={errMessage} />
        </div>
    );
}
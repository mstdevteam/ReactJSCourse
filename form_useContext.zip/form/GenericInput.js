import GenericInputDrilling from "./GenericInputDrilling";


export default function GenericInput() {
    return (
        <>
            <span>insert content</span>
             <GenericInputDrilling  />
            <span>field required !</span>
        </>
    )
}
